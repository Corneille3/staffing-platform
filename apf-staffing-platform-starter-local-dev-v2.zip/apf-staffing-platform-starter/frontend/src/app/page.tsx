export default function HomePage() {
  return (
    <main style={{ padding: 24, fontFamily: 'Arial, sans-serif' }}>
      <h1>APF Staffing Platform</h1>
      <p>Web MVP starter is running.</p>
      <ul>
        <li>Frontend: Next.js</li>
        <li>Backend API: FastAPI</li>
        <li>Database: PostgreSQL</li>
      </ul>
    </main>
  );
}
