import type { Metadata } from "next";
import React from "react";

export const metadata: Metadata = {
  title: "APF Staffing Platform",
  description: "APF staffing platform MVP starter",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
