"""SQLAlchemy model placeholder."""
