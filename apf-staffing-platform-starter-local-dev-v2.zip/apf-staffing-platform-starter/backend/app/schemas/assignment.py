"""Pydantic schema placeholder."""
