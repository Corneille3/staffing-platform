from fastapi import APIRouter

router = APIRouter()


@router.get('')
def list_workers() -> dict[str, list]:
    return {'items': []}
