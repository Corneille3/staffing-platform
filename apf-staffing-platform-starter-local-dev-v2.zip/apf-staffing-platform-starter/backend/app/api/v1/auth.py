from fastapi import APIRouter

router = APIRouter()


@router.get('/me')
def get_current_user() -> dict[str, str]:
    return {
        'message': 'Clerk-backed auth placeholder. Implement token verification next.',
    }
