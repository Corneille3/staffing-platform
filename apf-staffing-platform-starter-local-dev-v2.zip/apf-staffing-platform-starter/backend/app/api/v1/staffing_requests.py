from fastapi import APIRouter

router = APIRouter()


@router.get('')
def list_staffing_requests() -> dict[str, list]:
    return {'items': []}
