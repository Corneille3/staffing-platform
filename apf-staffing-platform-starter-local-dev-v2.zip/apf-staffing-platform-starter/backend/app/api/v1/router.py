from fastapi import APIRouter
from app.api.v1 import auth, organizations, workers, staffing_requests

api_router = APIRouter()
api_router.include_router(auth.router, prefix='/auth', tags=['auth'])
api_router.include_router(organizations.router, prefix='/organizations', tags=['organizations'])
api_router.include_router(workers.router, prefix='/workers', tags=['workers'])
api_router.include_router(staffing_requests.router, prefix='/staffing-requests', tags=['staffing_requests'])
