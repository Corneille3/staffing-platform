"""SMS notification service placeholder."""
