"""In-app notification service placeholder."""
