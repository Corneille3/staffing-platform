"""Email notification service placeholder."""
