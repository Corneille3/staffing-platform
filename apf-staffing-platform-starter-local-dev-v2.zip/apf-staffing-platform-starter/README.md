# APF Staffing Platform Starter

This repository is the starter baseline for the APF staffing platform MVP.

## Local development stack

Services:
- `frontend`: Next.js web app on `http://localhost:3000`
- `backend`: FastAPI API on `http://localhost:8000`
- `db`: PostgreSQL 16 on `localhost:5432`

## First-time local setup

1. Copy environment files:

```bash
cp backend/.env.example backend/.env
cp frontend/.env.local.example frontend/.env.local
```

2. Start the stack:

```bash
docker compose up --build
```

3. Run the first migration:

```bash
docker compose exec backend alembic upgrade head
```

4. Open the apps:
- frontend: `http://localhost:3000`
- backend docs: `http://localhost:8000/docs`
- health: `http://localhost:8000/health`

## Notes

- Local auth is scaffolded for Clerk but not fully enforced yet.
- The backend uses Docker Compose Postgres in local development.
- Production infrastructure remains Terraform-managed under `infra/`.
